@extends('layouts.frontend')
@section('contenido')
<section class="container-fluid fondo">
	<div class="container">
		<div class="row transparencia">
			<div class="col-sm-10 col-sm-offset-1 col-md-6 col-md-offset-3">
				<h2>
					CONTACTO
				</h2>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
				<p>
					Av. Las Palmeras 3943, Los Olivos, Lima&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;E-mail: contacto@apupal.com
				</p>
				<form class="form-horizontal" name="contacto" action="{{url()}}/contacto" method="post" id="contacto">
					<div class="form-group">
						<div class="col-sm-12">
							<input type="text" class="form-control inputbox" id="nombre" name="nombre" placeholder="Nombres y Apellidos">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-6">
							<input type="tel" class="form-control inputbox" id="telefono" name="tlefono" placeholder="Teléfono">
						</div>
						<div class="col-sm-6">
							<input type="email" class="form-control inputbox" id="email" name="email" placeholder="E-mail">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-12">
							<textarea name="mensaje" id="mensaje" class="form-control inputbox" placeholder="Mensaje"></textarea>
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-12">
							<input type="image" src="{{url()}}/img/boton-enviar.jpg" title="Enviar" class="pull-right">
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>
<section class="container-fluid">
	<div class="embed-responsive embed-responsive-16by9">
		<iframe class="embed-responsive-item" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAWBL62XeLy-mOXGMQZgTKrqjLIRe4ihX8&q=Zarte,Lima+Peru"></iframe>
	</div>
</section>
@stop